package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FbService {
@Autowired
Repo repo;
	public Feedback add(Feedback fb) {
		// TODO Auto-generated method stub
		return repo.save(fb);
		
	}

}

package com.example.demo;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Feedback {
	@Id
private String message;

public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
@Override
public String toString() {
	return "Feedback [message=" + message + "]";
}
public Feedback(String message) {
	super();
	
	this.message = message;
}

	
	
}

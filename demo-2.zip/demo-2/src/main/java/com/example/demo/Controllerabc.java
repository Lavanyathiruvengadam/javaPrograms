package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.stereotype.Controller;
@Controller

public class Controllerabc {
	@Autowired
    Repo repo;
	@Autowired
	FbService service;
	@RequestMapping(value = "/",method = RequestMethod.GET)
	public String home()
	{

		return "feedback";
	}
		@RequestMapping(value = "/feedback", method = RequestMethod.POST)
	public String Login(@ModelAttribute("feedback") Feedback fb, ModelMap model) {
		
		System.out.println(fb.getMessage());
		service.add(fb);
		return "Feedback Stored in database Successfully";
		
		
	}	
}


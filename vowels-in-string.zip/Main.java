import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		String str;
         int len ,count = 0;
         System.out.println("Enter a String");
         Scanner sc = new Scanner(System.in);
         str = sc.nextLine();
         len = str.length();
         for(int ind = 0; ind < len; ind++)
         {
             char ch = str.charAt(ind);
             if(ch == 'A' ||ch  == 'E' || ch== 'I' || ch =='O' ||  ch == 'U' || ch == 'a' || ch == 'e' || ch == 'i' || ch =='o' ||  ch == 'u' )
             count++;
         }
        System.out.println("No. of Vowels in a String is :"+ count);
     }
}
	


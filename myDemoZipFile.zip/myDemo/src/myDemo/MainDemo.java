package myDemo;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;
public class MainDemo {
	@Test
	public void invokeBrowser() {
			try {
//INVOKE FIREFOX	
				System.setProperty("webdriver.gecko.driver","C:\\Users\\Lavanya T\\Downloads\\firefoxdriver\\geckodriver.exe");
			    DesiredCapabilities capabilities = DesiredCapabilities.firefox();
				WebDriver driver = new FirefoxDriver(capabilities);
//MAXIMIZE WINDOW
				driver.manage().window().maximize();
//INVOKE WEBSITE
				driver.navigate().to("http://automationpractice.com/index.php");
 //LOGIN ACCOUNT	
			    driver.findElement(By.className("login")).click();
				driver.findElement(By.name("email")).sendKeys("lavanyavsi1999@gmail.com");
				driver.findElement(By.name("passwd")).sendKeys("Lavanya2@");
				driver.findElement(By.id("SubmitLogin")).click();
//ADD ITEM IN CART
                driver.findElement(By.id("search_query_top")).sendKeys("Summer Dresses > Printed Summer Dress");
				driver.findElement(By.name("submit_search")).click();
				driver.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div[2]/ul/li[1]/div/div[1]/div/a[1]/img")).click();
                driver.findElement(By.xpath("/html/body/div/div[2]/div/div[4]/div/div/div/div[4]/form/div/div[3]/div[1]/p/button/span")).click();
				System.out.println("item added in the cart");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
 public static void main(String[] args)  {
           MainDemo ref = new MainDemo();
           ref.invokeBrowser();
}}


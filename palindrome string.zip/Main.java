import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    System.out.println("Enter String");
	    Scanner sc = new Scanner(System.in);
	    String str,reverse = "";
	    str=sc.nextLine();
	    int len=str.length();
	    for(int ind = len-1;ind >=0; ind --)
	    reverse = reverse + str.charAt(ind);
	    if(str.equals(reverse))
	    System.out.println("palindrome");
	    else
	    System.out.println("not a palindrome");
	    }
}
